﻿using GerenciadorDeLivraria.Communication.Requests;
using GerenciadorDeLivraria.Communication.Responses;
using GerenciadorDeLivraria.Models;
using Microsoft.AspNetCore.Mvc;

namespace GerenciadorDeLivraria.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BookController : BaseController
{
    [HttpGet]
    [Route("api/livros")]
    [ProducesResponseType(typeof(List<Book>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
    public IActionResult GetAllLivros()
    {
        return Ok("Endpoint implementado com sucesso!");
    }

    [HttpGet]
    [Route("api/livros/{id}")]
    [ProducesResponseType(typeof(Book), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
    public IActionResult GetLivro(int id)
    {
        return Ok("Endpoint implementado com sucesso!");
    }

    [HttpPost]
    [Route("api/livros")]
    [ProducesResponseType(typeof(ResponseRegisterBookJson), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
    public IActionResult AddLivro([FromBody] RequestRegisterBookJson livro)
    {
        var livroAdicionado = new ResponseRegisterBookJson
        {
            Autor = livro.Autor,
            Titulo = livro.Titulo,
            Estoque = livro.Estoque,
            Genero = livro.Genero,
            Preco = livro.Preco
        };
        return Ok(livroAdicionado);
    }
}
